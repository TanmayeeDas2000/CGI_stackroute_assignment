from flask import Flask, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb://127.0.0.1:27017")
db = client.Onlineshopping
collection = db.products

# CREATE Operation
@app.route('/products', methods=['POST'])
def create_product():
    thing = request.get_json()
    insert_result = collection.insert_many(thing)
    return jsonify({"message": "details entered successfully", "id": str(insert_result.inserted_id)}), 201

# READ Operation
@app.route('/products',methods=['GET'])
def get_products():
    products = list(collection.find())
    for product in products:
        product['_id'] = str(product['_id'])
    return jsonify(products), 200


if __name__ =='__main__':
    app.run(debug=True)